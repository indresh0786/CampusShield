# CampusShield Ultimate

A fresh Django project that keeps the original CampusShield visual flow and adds selected advanced features without turning SOS into a long form.

## Included
- Original premium Dashboard, History and Command Center style
- Quick SOS cards: Medical, Fire, Security, Accident, Other
- Automatic browser geolocation when the SOS page opens
- Nearest available responder assignment (when responder locations are available)
- Responder live-location sharing
- Command Center polling for new SOS alerts every 3 seconds
- Special Web Audio siren + browser notification for responders (requires one click on **Enable SOS Alarm** because browsers block autoplay)
- Campus-wide emergency broadcasts
- **I'm Safe** acknowledgement for users
- Incident history, status, priority, escalation, evidence, silent SOS, analytics, map links

## Run on Windows / VS Code
Open the folder containing `manage.py`, then:

```powershell
python -m venv venv
.\venv\Scripts\python.exe -m pip install -r requirements.txt
.\venv\Scripts\python.exe manage.py migrate
.\venv\Scripts\python.exe manage.py createsuperuser
.\venv\Scripts\python.exe manage.py runserver
```

Open http://127.0.0.1:8000/

## Responder setup
The Command Center is intentionally restricted to staff users. Use the superuser you created, or mark a user as `is_staff` in Django admin.

For nearest-responder assignment, sign in as the responder, open Command Center, and press **Share responder location**. Press **Enable SOS Alarm** once to allow the browser to play the special alert tone and request notification permission.

## Multi-phone demo on same Wi-Fi
Run:
```powershell
.\venv\Scripts\python.exe manage.py runserver 0.0.0.0:8000
```
Find the laptop IPv4 using `ipconfig`, then open `http://YOUR-LAPTOP-IP:8000/` on phones connected to the same Wi-Fi. Windows Firewall may ask you to allow Python on Private networks.

Note: browser geolocation/notifications can be restricted on plain HTTP when accessed through a LAN IP. For a production deployment use HTTPS.
