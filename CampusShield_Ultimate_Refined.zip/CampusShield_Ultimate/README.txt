CAMPUSSHIELD - Campus Emergency & Safety App
Hackathon Problem Statement #12

WHAT IT DOES
Student/staff can register, login, send an emergency alert, choose category, share browser GPS location, view incident history and track status. Staff responders get a dashboard to view alerts, open locations on OpenStreetMap and mark incidents Responding/Resolved.

FIRST-TIME SETUP (Windows / VS Code)
1. Install Python and VS Code.
2. Open the CampusShield folder in VS Code.
3. Open Terminal > New Terminal.
4. Create virtual environment:
   python -m venv venv
5. Activate it:
   venv\Scripts\activate
6. Install Django:
   pip install -r requirements.txt
7. Create database tables:
   python manage.py makemigrations
   python manage.py migrate
8. Create responder/admin account:
   python manage.py createsuperuser
   Enter username, email (email can be blank) and password.
9. Start project:
   python manage.py runserver
10. Open browser:
    http://127.0.0.1:8000/

STUDENT DEMO
- Click Create account.
- Register a student account.
- Home > SOS > select emergency > Get my current location > allow browser location > Send Emergency Alert.
- Open History to track status.

RESPONDER DEMO
- Logout student.
- Login using the superuser account created above.
- Open http://127.0.0.1:8000/responder/
- See incoming alerts, open their location and change status to Responding or Resolved.
- Django admin is also available at http://127.0.0.1:8000/admin/

IMPORTANT
- Location permission works best on localhost (the runserver URL) or HTTPS.
- Replace sample emergency contacts on the home page with your college's real authorized contacts before a real deployment.
- This is a hackathon prototype, not a replacement for official emergency services.

PROJECT STACK
Frontend: HTML, CSS, JavaScript
Backend: Python Django
Database: SQLite
Location: Browser Geolocation + OpenStreetMap
