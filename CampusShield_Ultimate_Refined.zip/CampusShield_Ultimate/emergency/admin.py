from django.contrib import admin
from .models import Emergency,EmergencyContact,ResponderProfile,Broadcast,SafetyAck
admin.site.register([Emergency,EmergencyContact,ResponderProfile,Broadcast,SafetyAck])
