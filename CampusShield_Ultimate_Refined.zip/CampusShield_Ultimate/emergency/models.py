from django.db import models
from django.contrib.auth.models import User

class ResponderProfile(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE,related_name='responder_profile')
    display_name=models.CharField(max_length=80,blank=True)
    team=models.CharField(max_length=50,default='Campus Response')
    phone=models.CharField(max_length=20,blank=True)
    latitude=models.FloatField(null=True,blank=True)
    longitude=models.FloatField(null=True,blank=True)
    is_available=models.BooleanField(default=True)
    last_seen=models.DateTimeField(auto_now=True)
    def __str__(self): return self.display_name or self.user.username

class Emergency(models.Model):
    TYPES=[('Medical','Medical Emergency'),('Fire','Fire Emergency'),('Security','Security Issue'),('Accident','Accident'),('Other','Other Incident')]
    STATUS=[('Pending','Pending'),('Responding','Responding'),('Resolved','Resolved')]
    PRIORITY=[('Critical','Critical'),('High','High'),('Medium','Medium')]
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    emergency_type=models.CharField(max_length=20,choices=TYPES)
    description=models.TextField(blank=True)
    latitude=models.CharField(max_length=30,blank=True)
    longitude=models.CharField(max_length=30,blank=True)
    priority=models.CharField(max_length=10,choices=PRIORITY,default='High')
    status=models.CharField(max_length=20,choices=STATUS,default='Pending')
    silent_mode=models.BooleanField(default=False)
    evidence=models.ImageField(upload_to='evidence/',blank=True,null=True)
    responder=models.ForeignKey(User,on_delete=models.SET_NULL,null=True,blank=True,related_name='assigned_emergencies')
    escalated=models.BooleanField(default=False)
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now=True)
    resolved_at=models.DateTimeField(blank=True,null=True)
    def __str__(self): return f'CS-{self.pk or "NEW"} • {self.user.username} • {self.emergency_type}'

class EmergencyContact(models.Model):
    name=models.CharField(max_length=80); role=models.CharField(max_length=80,blank=True); phone=models.CharField(max_length=20); icon=models.CharField(max_length=8,default='☎️')
    def __str__(self): return self.name

class Broadcast(models.Model):
    LEVELS=[('Info','Info'),('Warning','Warning'),('Critical','Critical')]
    title=models.CharField(max_length=120)
    message=models.TextField()
    level=models.CharField(max_length=12,choices=LEVELS,default='Warning')
    area=models.CharField(max_length=100,blank=True,default='Entire Campus')
    active=models.BooleanField(default=True)
    created_by=models.ForeignKey(User,on_delete=models.SET_NULL,null=True,blank=True)
    created_at=models.DateTimeField(auto_now_add=True)
    def __str__(self): return self.title

class SafetyAck(models.Model):
    broadcast=models.ForeignKey(Broadcast,on_delete=models.CASCADE,related_name='acks')
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    is_safe=models.BooleanField(default=True)
    created_at=models.DateTimeField(auto_now_add=True)
    class Meta: unique_together=('broadcast','user')
