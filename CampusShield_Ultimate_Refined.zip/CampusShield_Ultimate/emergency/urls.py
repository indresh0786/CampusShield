from django.urls import path
from . import views
urlpatterns=[
 path('',views.home,name='home'), path('register/',views.register,name='register'), path('sos/',views.send_alert,name='send_alert'), path('history/',views.history,name='history'), path('responder/',views.responder,name='responder'),
 path('status/<int:pk>/<str:status>/',views.update_status,name='update_status'), path('escalate/<int:pk>/',views.escalate,name='escalate'), path('broadcast/',views.create_broadcast,name='create_broadcast'), path('safe/<int:pk>/',views.im_safe,name='im_safe'), path('api/responder-location/',views.responder_location,name='responder_location'), path('api/alerts/',views.alert_feed,name='alert_feed')]
