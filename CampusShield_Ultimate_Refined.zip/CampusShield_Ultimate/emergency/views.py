import json, math
from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required,user_passes_test
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.db.models import Count
from django.http import JsonResponse
from django.utils import timezone
from django.views.decorators.http import require_POST
from .models import Emergency,EmergencyContact,ResponderProfile,Broadcast,SafetyAck

def register(request):
    form=UserCreationForm(request.POST or None)
    if request.method=='POST' and form.is_valid():
        user=form.save(); login(request,user); messages.success(request,'Account created. Welcome to CampusShield.'); return redirect('home')
    return render(request,'emergency/register.html',{'form':form})

def _contacts():
    q=EmergencyContact.objects.all()
    return q if q.exists() else [{'icon':'🛡️','name':'Campus Security','role':'24×7 response desk','phone':'112'},{'icon':'🚑','name':'Medical Help','role':'Emergency assistance','phone':'108'},{'icon':'🔥','name':'Fire Emergency','role':'Fire & rescue','phone':'101'}]

def _distance(lat1,lon1,lat2,lon2):
    r=6371; p1,p2=math.radians(lat1),math.radians(lat2); dp=math.radians(lat2-lat1); dl=math.radians(lon2-lon1)
    a=math.sin(dp/2)**2+math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return 2*r*math.asin(math.sqrt(a))

def _assign_nearest(e):
    profiles=list(ResponderProfile.objects.filter(is_available=True,user__is_staff=True).select_related('user'))
    if not profiles: return None
    try: lat,lon=float(e.latitude),float(e.longitude)
    except (TypeError,ValueError):
        e.responder=profiles[0].user; e.save(update_fields=['responder']); return profiles[0]
    valid=[p for p in profiles if p.latitude is not None and p.longitude is not None]
    p=min(valid,key=lambda x:_distance(lat,lon,x.latitude,x.longitude)) if valid else profiles[0]
    e.responder=p.user; e.save(update_fields=['responder']); return p

@login_required
def home(request):
    qs=Emergency.objects.filter(user=request.user)
    broadcast=Broadcast.objects.filter(active=True).order_by('-created_at').first()
    acknowledged=bool(broadcast and SafetyAck.objects.filter(broadcast=broadcast,user=request.user).exists())
    return render(request,'emergency/home.html',{'recent':qs.order_by('-created_at')[:4],'active':qs.exclude(status='Resolved').count(),'resolved':qs.filter(status='Resolved').count(),'contacts':_contacts(),'broadcast':broadcast,'acknowledged':acknowledged})

@login_required
def send_alert(request):
    if request.method=='POST':
        typ=request.POST.get('emergency_type','Other')
        default_priority={'Security':'Critical','Fire':'Critical','Medical':'High','Accident':'High','Other':'High'}.get(typ,'High')
        e=Emergency.objects.create(user=request.user,emergency_type=typ,description=request.POST.get('description',''),latitude=request.POST.get('latitude',''),longitude=request.POST.get('longitude',''),priority=request.POST.get('priority') or default_priority,silent_mode=request.POST.get('silent_mode')=='on',evidence=request.FILES.get('evidence'))
        p=_assign_nearest(e)
        messages.success(request,'SOS SENT • '+(('Nearest responder assigned: '+(p.display_name or p.user.username)) if p else 'Response team notified.'))
        return redirect('history')
    return render(request,'emergency/send_alert.html')

@login_required
def history(request): return render(request,'emergency/history.html',{'items':Emergency.objects.filter(user=request.user).order_by('-created_at')})
def staff_check(user): return user.is_authenticated and user.is_staff

@user_passes_test(staff_check)
def responder(request):
    items=Emergency.objects.all().order_by('-created_at'); types=list(Emergency.objects.values('emergency_type').annotate(total=Count('id')).order_by('-total')); resolved=items.filter(status='Resolved')
    times=[(e.resolved_at-e.created_at).total_seconds()/60 for e in resolved if e.resolved_at]
    stats={'total':items.count(),'active':items.exclude(status='Resolved').count(),'critical':items.filter(priority='Critical').exclude(status='Resolved').count(),'resolved':resolved.count(),'avg':round(sum(times)/len(times),1) if times else 0}
    broadcast=Broadcast.objects.filter(active=True).order_by('-created_at').first()
    return render(request,'emergency/responder.html',{'items':items,'stats':stats,'types':types,'broadcast':broadcast,'safe_count':broadcast.acks.count() if broadcast else 0})

@user_passes_test(staff_check)
def update_status(request,pk,status):
    e=get_object_or_404(Emergency,pk=pk)
    if status in ['Pending','Responding','Resolved']:
        e.status=status
        if status=='Responding': e.responder=request.user
        if status=='Resolved': e.resolved_at=timezone.now()
        e.save()
    return redirect('responder')

@user_passes_test(staff_check)
def escalate(request,pk):
    e=get_object_or_404(Emergency,pk=pk); e.escalated=True; e.priority='Critical'; e.save(); messages.warning(request,f'Incident CS-{e.pk:04d} escalated.'); return redirect('responder')

@user_passes_test(staff_check)
@require_POST
def create_broadcast(request):
    title=request.POST.get('title','Campus Safety Alert').strip(); msg=request.POST.get('message','').strip(); area=request.POST.get('area','Entire Campus').strip()
    if msg: Broadcast.objects.update(active=False); Broadcast.objects.create(title=title,message=msg,area=area,level=request.POST.get('level','Warning'),created_by=request.user); messages.success(request,'Campus-wide broadcast sent.')
    return redirect('responder')

@login_required
@require_POST
def im_safe(request,pk):
    b=get_object_or_404(Broadcast,pk=pk,active=True); SafetyAck.objects.update_or_create(broadcast=b,user=request.user,defaults={'is_safe':True}); messages.success(request,"You're marked safe. Thank you."); return redirect('home')

@user_passes_test(staff_check)
@require_POST
def responder_location(request):
    try: data=json.loads(request.body or '{}'); p,_=ResponderProfile.objects.get_or_create(user=request.user); p.latitude=float(data['latitude']); p.longitude=float(data['longitude']); p.is_available=True; p.save(); return JsonResponse({'ok':True})
    except Exception: return JsonResponse({'ok':False},status=400)

@user_passes_test(staff_check)
def alert_feed(request):
    try: after=int(request.GET.get('after',0))
    except ValueError: after=0
    qs=Emergency.objects.filter(id__gt=after).order_by('id')[:20]
    return JsonResponse({'alerts':[{'id':e.id,'type':e.emergency_type,'priority':e.priority,'user':e.user.username,'silent':e.silent_mode,'lat':e.latitude,'lng':e.longitude} for e in qs]})
